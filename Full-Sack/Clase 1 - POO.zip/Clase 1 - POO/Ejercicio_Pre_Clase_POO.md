# Ejercicio Pre-Clase – Introducción a Programación Orientada a Objetos (POO)
**Módulo 4 – Actividad Complementaria**  
**Entrega opcional para nota:**  
- **10 puntos** → como Ejercicio del Módulo 4  
- **5 puntos** → incluido en la Evaluación Final del Módulo 4

---

## 📌 Objetivo del Ejercicio
Este trabajo tiene como finalidad que el estudiante desarrolle una comprensión inicial sobre los conceptos fundamentales de la Programación Orientada a Objetos (POO): **objetos, atributos, métodos, herencia y polimorfismo**, mediante una actividad simple y práctica basada en una “familia”.

No se requiere experiencia previa en programación.

---

## 📘 Instrucciones Generales
Crea una **Mini-Familia de Objetos** utilizando únicamente texto, dibujos o esquemas (no es necesario escribir código).  
Tu trabajo debe ser claro, creativo y cumplir con todos los puntos solicitados.

Puedes trabajar con:
- Tu familia real  
- Una familia inventada  
- Una familia fantástica (robots, animales, superhéroes, etc.)

Además, **debes enviar tu trabajo individual al correo:**  
📧 **rgonzalezmindhubweb@gmail.com**

---

## 🧩 Actividades a Realizar

### 1. Estructura Familiar (mínimo 3 miembros)
Incluye:
- 1 abuelo/a  
- 1 padre/madre  
- 1 hijo/a  

---

### 2. Descripción como Objetos
Para cada miembro define:

#### **Atributos (3 por persona):**  
Características permanentes.  
Ejemplos: edad, profesión, nivelDeMagia, colorFavorito.

#### **Métodos (2 por persona):**  
Acciones que realiza.  
Ejemplos: cocinar(), leer(), entrenar(), cantar().

---

### 3. Herencia
Describe brevemente:
- **2 atributos o cualidades** que el hijo/heredero recibe del padre/madre.  
- **1 característica** propia del hijo/a (no heredada).

---

### 4. Polimorfismo
Define **una acción en común** que *todos* los miembros de la familia realizan, pero **cada uno la ejecuta de manera diferente**.

Ejemplo:  
- “saludar”:  
  - Abuelo → da la mano  
  - Padre → abraza  
  - Hijo → choca los cinco  

Máximo 4 líneas.

---

### 5. Presentación Visual (opcional, +1 punto extra)
Dibuja un pequeño **árbol familiar** o esquema que muestre la relación entre los personajes.  
Puede ser una foto o imagen digital.

---

## 📤 Formato de Entrega
Puedes entregar tu trabajo en:  
- PDF  
- Word  
- Markdown  
- Imagen o foto clara  

**Extensión sugerida:** máximo 1 página.

**Enviar a:** 📧 *rgonzalezmindhubweb@gmail.com*

---

## 🧮 Puntaje y Evaluación

| Criterio | Puntaje |
|----------|---------|
| Estructura familiar mínima (3 miembros) | 2 pts |
| Atributos y métodos definidos | 3 pts |
| Explicación de herencia | 2 pts |
| Ejemplo de polimorfismo | 2 pts |
| Claridad y presentación visual | 1 pt |
| **Total** | **10 pts** |

Si se usa como parte de la Evaluación Final del Módulo 4, el puntaje máximo será **5 puntos**, proporcionalmente ajustado.

---

## ✔️ Propósito Pedagógico
Esta actividad prepara la base conceptual para la clase de POO, permitiendo que todos los estudiantes —con o sin experiencia previa— lleguen con una comprensión intuitiva de:
- Objetos  
- Clases  
- Atributos  
- Métodos  
- Herencia  
- Polimorfismo  

Esto facilita una clase más fluida y participativa.