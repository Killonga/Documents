
class Padre {
  constructor(nombre, edad) {
    this.nombre = nombre;
    this.edad = edad;
  }
  saludar() {
    console.log(`Hola, soy el papá ${this.nombre}.`);
  }
  saberAnnoNacimiento(){
    let annoNacimiento = new Date().getFullYear() - this.edad;
    console.log("Mi fecha de nacimiento es: "+annoNacimiento);
  }
}
const papa = new Padre("Carlos", 50);
const papa2 = new Padre("Papito Corazón",27);
console.log(papa.nombre);
console.log(papa.edad);

papa.saludar();
papa.saberAnnoNacimiento();
console.log("-------------------------------");
papa2.saludar();
papa2.saberAnnoNacimiento();


class Persona {
  #rut;
  #nombre;
  constructor(nombre, rut) {
    this.#nombre = nombre;
    this.#rut = rut;
  }
  //método getter para utilizar propiedades encapsuladas
  getRut() {
    return `RUT protegido de ${this.#nombre}`;
  }
  getNombre(){
    return this.#nombre;
  }
}
const persona = new Persona("Ana", "11.111.111-1");
console.log(persona.rut); //undefined
//console.log(persona.getRut());
console.log(persona.nombre);

console.log(persona.getRut()); 
console.log(persona.getNombre());


class Papa {
  constructor(nombre) {
    this.nombre = nombre;
  }
  saludar() {
    console.log("Hola, soy una persona.");
  }
  trabajar(){
    console.log("estoy trabajando");
  }
}
class Hijo extends Papa {
    jugar() {
      console.log(`${this.nombre} está jugando.`);
    }

}
const padre = new Papa("Matías 1ro")
const hijo = new Hijo("Matías 2do");
padre.saludar();
hijo.saludar();
hijo.jugar();
padre.trabajar();





