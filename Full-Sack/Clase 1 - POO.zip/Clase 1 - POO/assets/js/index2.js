class Persona {
  saludar() {
    console.log("Hola, soy una persona.");
  }
}
class Padre extends Persona {
  saludarTranquilo() {
    console.log("Hola, soy el papá.");
  }
}
class Hijo extends Padre {
  saludarRapido() {
    console.log("Hola, soy el hijo.");
  }
}
new Persona().saludar();
new Padre().saludar();
new Hijo().saludar();
new Hijo().saludarTranquilo();
new Hijo().saludarRapido();