# **Clase: Programación Orientada a Objetos (POO)**

------------------------------------------------------------------------

# **1. ¿Qué es la POO?**

Según Microsoft Learn, *"la programación orientada a objetos modela las
aplicaciones como colecciones de objetos que interactúan"*.\
La POO facilita organizar el código representando elementos del mundo
real.\
Permite mantener, escalar y entender mejor los sistemas complejos.\
**Fuente:**
https://learn.microsoft.com/es-es/dotnet/csharp/fundamentals/tutorials/oop

------------------------------------------------------------------------

# **2. Conceptos básicos usando la familia**

## **Clase**

> *"Una clase es una construcción que permite crear tipos personalizados
> con propiedades, métodos y eventos."* --- Microsoft Learn\
> Una clase es un molde que define cómo serán los objetos.\
> Equivale a la "genética" o molde de cómo son los miembros de la
> familia.\
> **Fuente:**
> https://learn.microsoft.com/es-es/dotnet/visual-basic/programming-guide/language-features/objects-and-classes/classes

## **Objeto**

> *"Un objeto es una instancia de una clase."* --- Microsoft Learn\
> Es un miembro real de la familia creado a partir del molde.\
> Posee valores propios como nombre o edad.\
> **Fuente:**
> https://learn.microsoft.com/es-es/dotnet/visual-basic/programming-guide/language-features/objects-and-classes/objects

## **Propiedades**

> *"Las propiedades son miembros que proporcionan un mecanismo flexible
> para leer, escribir o calcular valores."* --- Microsoft Learn\
> Son las características del objeto, como nombre, edad o apellido.\
> Cada miembro de la familia puede tener valores distintos.\
> **Fuente:**
> https://learn.microsoft.com/es-es/dotnet/csharp/programming-guide/classes-and-structs/properties

## **Métodos**

> *"Los métodos definen el comportamiento de los objetos."* ---
> Microsoft Learn\
> Son acciones como saludar, caminar o comer.\
> Funcionan como funciones dentro de un objeto.\
> **Fuente:**
> https://learn.microsoft.com/es-es/dotnet/csharp/fundamentals/object-oriented/

## **Constructor**

> *"Un constructor es un método especial que se ejecuta al crear una
> instancia de una clase."* --- Microsoft Learn\
> Actúa como el "acta de nacimiento" del miembro de la familia.\
> Inicializa propiedades como nombre y edad.\
> **Fuente:**
> https://learn.microsoft.com/es-es/dotnet/csharp/programming-guide/classes-and-structs/constructors

------------------------------------------------------------------------

# **3. Creación de Objetos**

## **3.1. Objeto literal (ejemplo: Abuelo)**

``` js
const abuelo = {
  nombre: "Juan",
  edad: 75,
  saludar() {
    console.log("Hola, soy el abuelo Juan.");
  }
};
abuelo.saludar();

// VS

class Abuelo{
  constructor(nombre, edad){
    this.nombre = nombre;
    this.edad = edad;
  }
  saludar(){
    console.log("Hola, soy el abuelo Juan.");
  }
}

const abuelito = new Abuelo("Juan", 75);
abuelito.saludar();


```

## **3.2. Objeto mediante Clase + Constructor (Padre)**

``` js
class Padre {
  constructor(nombre, edad) {
    this.nombre = nombre;
    this.edad = edad;
  }
  saludar() {
    console.log(`Hola, soy el papá ${this.nombre}.`);
  }
}
const papa = new Padre("Carlos", 50);
console.log(papa.nombre)
papa.saludar();
```

------------------------------------------------------------------------

# **4. Los Pilares de la POO en Analogía Familiar**

## **4.1. Encapsulamiento**

> *"La encapsulación consiste en ocultar los detalles internos y exponer
> solo lo necesario."* --- Microsoft Learn\
> Es como mantener ciertos aspectos privados dentro de la familia.\
> Protege y organiza la información sensible.\
> **Fuente:**
> https://learn.microsoft.com/es-es/dotnet/csharp/fundamentals/object-oriented/

### **Ejemplo**

``` js
class Persona {
  #rut;
  constructor(nombre, rut) {
    this.nombre = nombre;
    this.#rut = rut;
  }
  getRut() {
    return `RUT protegido de ${this.nombre}`;
  }
}
const persona = new Persona("Ana", "11.111.111-1");
console.log(persona.getRut());
```

------------------------------------------------------------------------

## **4.2. Herencia**

> *"La herencia permite crear clases que heredan características de
> otras clases."* --- Microsoft Learn\
> Es como cuando un hijo recibe rasgos y comportamientos de sus padres.\
> Evita duplicar código y permite jerarquías lógicas.\
> **Fuente:**
> https://learn.microsoft.com/es-es/dotnet/csharp/fundamentals/object-oriented/inheritance

### **Ejemplo**

``` js
class Persona {
  constructor(nombre) {
    this.nombre = nombre;
  }
  saludar() {
    console.log("Hola, soy una persona.");
  }
}
class Hijo extends Persona {
  jugar() {
    console.log(`${this.nombre} está jugando.`);
  }
}
const hijo = new Hijo("Matías");
hijo.saludar();
hijo.jugar();
```

------------------------------------------------------------------------

## **4.3. Polimorfismo**

> *"El polimorfismo permite que una llamada a método produzca
> comportamientos distintos según el tipo del objeto."* --- Microsoft
> Learn\
> En la familia, todos pueden "saludar", pero cada uno lo hace
> distinto.\
> Permite que clases hijas modifiquen métodos de la clase padre.\
> **Fuente:**
> https://learn.microsoft.com/es-es/dotnet/visual-basic/programming-guide/language-features/objects-and-classes/polymorphism

### **Ejemplo**

``` js
class Persona {
  saludar() {
    console.log("Hola, soy una persona.");
  }
}
class Padre extends Persona {
  saludar() {
    console.log("Hola, soy el papá.");
  }
}
class Hijo extends Persona {
  saludar() {
    console.log("Hola, soy el hijo.");
  }
}
new Persona().saludar();
new Padre().saludar();
new Hijo().saludar();
```

------------------------------------------------------------------------

# **5. Demostración completa: Una pequeña familia**

``` js
class Persona {
  constructor(nombre, edad) {
    this.nombre = nombre;
    this.edad = edad;
  }
  saludar() {
    console.log("Hola, soy una persona.");
  }
}
class Padre extends Persona {
  saludar() {
    console.log(`Hola, soy el papá ${this.nombre}.`);
  }
}
class Hijo extends Persona {
  saludar() {
    console.log(`Hola, soy el hijo ${this.nombre}.`);
  }
}
const abuelo = { 
  nombre: "Pedro",
  edad: 80,
  saludar() { console.log("Hola, soy el abuelo Pedro."); }
};
const papa = new Padre("Carlos", 50);
const hijo = new Hijo("Matías", 15);
abuelo.saludar();
papa.saludar();
hijo.saludar();
```

------------------------------------------------------------------------

# **6. Mini--Ejercicio para los alumnos**

1.  Crea la clase `Persona` con nombre y edad.\
2.  Crea la clase `Madre` que herede de `Persona` y sobrescriba
    `saludar()`.\
3.  Crea una clase `Hija` que también herede y tenga un método
    `estudiar()`.\
4.  Instancia los 3 objetos y llama a todos sus métodos.\
5.  Observa polimorfismo y herencia en acción.
